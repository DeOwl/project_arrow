# tello_binom
Tello Edu library developed by DZ for BINOM Publishing

:construction: This library is still in construction and is subject to change! Use at your own risk! :construction:

## Installation

```
python3 setup.py install
```

## Example Usage

```python
from tello_binom import *
start()
takeoff()
land()
```


