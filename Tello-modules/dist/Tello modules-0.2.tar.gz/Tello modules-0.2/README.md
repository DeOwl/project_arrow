# tello_modules
Tello modules is a library built for using custom drone modules

:construction: This library is still in construction and is subject to change! Use at your own risk! :construction:

## Manual installation
For UNIX:
```
python3 setup.py install 
```

For Windows:
```
py -m pip setup.py install 
```
