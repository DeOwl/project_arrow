ser = None
connection_type = None